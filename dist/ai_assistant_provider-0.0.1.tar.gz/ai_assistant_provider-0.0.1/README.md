# AI Assistant Provider

## Installation

```bash
pip install ai-assistant-provider
```

